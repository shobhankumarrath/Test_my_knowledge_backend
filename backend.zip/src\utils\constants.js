module.exports = {
  SUCCESS_MESSAGE: "Email Sent Successfully",
  ERROR_MESSAGE: "FAILED TO SEND EMAIL",
  EMAIL_SUBJECT: "Your Quiz Score",
  ALLOWED_ORIGINS: [
    "http://localhost:5173",
    "https://shobhankumarrath.github.io", // ✅ correct for GitHub Pages
  ],
};
